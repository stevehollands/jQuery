# jQuery

## Second series of exercises

**IMPORTANT**.
All resources for the exercises are supplied.

## Exercise 1
When you click on the button, a dialog box appears with the message of your choice.

## Exercise 2
With a double click, change the width of the image to 500px;

## Exercise 3
Show or hide the text by clicking on the supplied links.

## Exercise 4
When you click on a color button, you change the color of the text of the div.

## Exercise 5
When the user focuses on a field, set its edge to "1px solid green". When the field is no longer sharp, set the border to "1px solid red".

## Exercise 6
When the mouse moves over a colored button, color the text. The text must turn black again when the mouse leaves the button.

## Exercise 7
Summary of series 1 and 2. The instructions can be found in the HTML file.