$(document).ready(function(){
    /* On click: Enlarge the font (120%) */
    
    
    /* On click: Decrease the font size (80%) */

    
    /* On click: Bold or normalize the green words */

    
    /* On click: Bold or normalize the green words */

    
    /* On click: Replace the logo with another image */
    
    
    /* On hover: Display the URL of links in a tooltip when hovering over links */
    
    
    /* On click: add "Chapter 1:" before the 1st title h2 and "Chapter 2:" before the 2nd title h2 */
    
});