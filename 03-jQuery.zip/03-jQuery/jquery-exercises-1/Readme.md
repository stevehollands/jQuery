# jQuery

## First series of exercises

**IMPORTANT**

HTML and jQuery files are included.
**Attention**.
Do not make changes to the jQuery file.
All versions are done via the main.js file.

## Exercise 1 :

Hide the "text" div.

## Exercise 2:

Display the "text" div.

## Exercise 3:

Change the font family of the "text" div to "Courier".

## Exercise 4:

Change the color of all "li" tags to red.

## Exercise 5:

Empty the "text_2" div.

## Exercise 6:

Hide all elements with a "to_hide" class.

## Exercise 7:

Delete all elements with a "delete" class.

## Exercise 8:

Give all the "li" elements of "ol" the color red.

## Exercise 9:

Give the "text_1" and "text_3" div a 5 px, dotted green border ("5px green dashed").

## Exercise 10:

JQuery is already present and allows you to hide all elements of the "to_hide" class. Add this class to the "text_3" div.