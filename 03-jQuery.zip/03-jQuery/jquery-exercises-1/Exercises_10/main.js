// Write your solution here
$(".to_hide").hide();